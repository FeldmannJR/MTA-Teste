function Player:msg(mesage)
    outputChatBox(mesage,self,255,255,255,true)
 end
 
 function msg(mesage)
     outputChatBox(mesage,getRootElement(),255,255,255,true)
 end
 



